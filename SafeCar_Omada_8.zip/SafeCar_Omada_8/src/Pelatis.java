import java.util.ArrayList;

class Pelatis {
    private String onomatoponimo;
    private String tilefono;
    private String email;
    private String iban;

    public Pelatis(String onomatoponimo, String tilefono, String email, String iban) {
        this.onomatoponimo = onomatoponimo;
        this.tilefono = tilefono;
        this.email = email;
        this.iban = iban;
    }

    // Getter and setter methods
    public String getOnomatoponimo() { return onomatoponimo; }
    public void setOnomatoponimo(String onomatoponimo) { this.onomatoponimo = onomatoponimo; }

    public String getTilefono() { return tilefono; }
    public void setTilefono(String tilefono) { this.tilefono = tilefono; }

    public String getEmail() { return email; }
    public void setEmail(String email) { this.email = email; }

    public String getIban() { return iban; }
    public void setIban(String iban) { this.iban = iban; }

    public void printData() {
        System.out.println("Pelatis: " + onomatoponimo + ", " + tilefono + ", " + email + ", " + iban);
    }
}