import java.util.ArrayList;

class Profora {
    private double pososto_profsofas;
    private String diakimeno_profsofas;
    private static ArrayList<Profora> proforaCatalog;

    public Profora(double pososto_profsofas, String diakimeno_profsofas) {
        this.pososto_profsofas = pososto_profsofas;
        this.diakimeno_profsofas = diakimeno_profsofas;
    }

    // Getter and setter methods
    public double getPososto() { return pososto_profsofas; }
    public void setPososto(double pososto_profsofas) { this.pososto_profsofas = pososto_profsofas; }

    public String getDiakimeno() { return diakimeno_profsofas; }
    public void setDiakimeno(String diakimeno_profsofas) { this.diakimeno_profsofas = diakimeno_profsofas; }

    public void addToCatalog() {
        if (proforaCatalog == null) {
            proforaCatalog = new ArrayList<>();
        }
        proforaCatalog.add(this);
    }

    public void printData() {
        System.out.println("Profora: " + pososto_profsofas + "%, " + diakimeno_profsofas);
    }
}
