

class Praktoras {
    private String onomatoponimo;
    private String eidikotita;
    private String tilefono;
 

    public Praktoras(String onomatoponimo, String eidikotita, String tilefono) {
        this.onomatoponimo = onomatoponimo;
        this.eidikotita = eidikotita;
        this.tilefono = tilefono;
    }

    // Getter and setter methods for onomatoponimo, eidikotita, and tilefono
    public String getOnomatoponimo() {
        return onomatoponimo;
    }

    public void setOnomatoponimo(String onomatoponimo) {
        this.onomatoponimo = onomatoponimo;
    }

    public String getEidikotita() {
        return eidikotita;
    }

    public void setEidikotita(String eidikotita) {
        this.eidikotita = eidikotita;
    }

    public String getTilefono() {
        return tilefono;
    }

    public void setTilefono(String tilefono) {
        this.tilefono = tilefono;
    }

    // Method to send insurance documents
    public void apostoliEgrafonAsfalistiki(String email, String documents) {
        System.out.println("Sending insurance documents to " + this.onomatoponimo + " at email: " + email);
        System.out.println("Documents: " + documents);
    }

    // Method to update client's insurance status
    public void enimerosiPelatiKatastasiAsfalistrou(String clientName, String status) {
        System.out.println("Updating insurance status for client " + clientName + " to: " + status);
    }
    
    // Method to print agent's data
    public void printData() {
        System.out.println("Praktoras: " + onomatoponimo + ", " + eidikotita + ", " + tilefono);
    }
}
