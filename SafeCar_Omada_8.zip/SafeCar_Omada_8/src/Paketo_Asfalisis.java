import java.util.ArrayList;

public class Paketo_Asfalisis {
    private String perigrafiPaketou;
    private static ArrayList<Paketo_Asfalisis> asfalisisCatalog;

    public Paketo_Asfalisis(String perigrafiPaketou) {
        this.perigrafiPaketou = perigrafiPaketou;
    }

    // Getter and setter methods for perigrafiPaketou
    public String getPerigrafiPaketou() {
        return perigrafiPaketou;
    }

    public void setPerigrafiPaketou(String perigrafiPaketou) {
        this.perigrafiPaketou = perigrafiPaketou;
    }

    // Method to add insurance packages to the catalog
    public static void addToCatalog(Paketo_Asfalisis paketoAsfalisis) {
        if (asfalisisCatalog == null) {
            asfalisisCatalog = new ArrayList<>();
        }
        asfalisisCatalog.add(paketoAsfalisis);
    }

    // Method to print data of all insurance packages in the catalog
    public static void printCatalog() {
        if (asfalisisCatalog != null) {
            System.out.println("Insurance Packages Catalog:");
            for (Paketo_Asfalisis paketo : asfalisisCatalog) {
                System.out.println("- " + paketo.getPerigrafiPaketou());
            }
        } else {
            System.out.println("No insurance packages in the catalog.");
        }
    }
}