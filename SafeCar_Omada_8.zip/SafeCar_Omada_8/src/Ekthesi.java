import java.util.ArrayList;

class Ekthesi {
    private String imerominia;
    private int arithmos_pinakidas;
    private String perigrafi_peristatikou;
    private static ArrayList<Ekthesi> ekthesiCatalog;

    public Ekthesi(String imerominia, int arithmos_pinakidas, String perigrafi_peristatikou) {
        this.imerominia = imerominia;
        this.arithmos_pinakidas = arithmos_pinakidas;
        this.perigrafi_peristatikou = perigrafi_peristatikou;
    }

    // Getter and setter methods
    public String getImerominia() { return imerominia; }
    public void setImerominia(String imerominia) { this.imerominia = imerominia; }

    public int getArithmosPinakidas() { return arithmos_pinakidas; }
    public void setArithmosPinakidas(int arithmos_pinakidas) { this.arithmos_pinakidas = arithmos_pinakidas; }

    public String getPerigrafiPeristatikou() { return perigrafi_peristatikou; }
    public void setPerigrafiPeristatikou(String perigrafi_peristatikou) { this.perigrafi_peristatikou = perigrafi_peristatikou; }

    public void addToCatalog() {
        if (ekthesiCatalog == null) {
            ekthesiCatalog = new ArrayList<>();
        }
        ekthesiCatalog.add(this);
    }

    public void printData() {
        System.out.println("Ekthesi: " + imerominia + ", " + arithmos_pinakidas + ", " + perigrafi_peristatikou);
    }
}