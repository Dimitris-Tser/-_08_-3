import java.util.ArrayList;

class Radevou {
    private String on;
    private String imerominia;
    private static ArrayList<Radevou> radevouCatalog;

    public Radevou(String on, String imerominia) {
        this.on = on;
        this.imerominia = imerominia;
    }

    // Getter and setter methods
    public String getOn() { return on; }
    public void setOn(String on) { this.on = on; }

    public String getImerominia() { return imerominia; }
    public void setImerominia(String imerominia) { this.imerominia = imerominia; }

    public void addToCatalog() {
        if (radevouCatalog == null) {
            radevouCatalog = new ArrayList<>();
        }
        radevouCatalog.add(this);
    }

    public void printData() {
        System.out.println("Radevou: " + on + ", " + imerominia);
    }
}