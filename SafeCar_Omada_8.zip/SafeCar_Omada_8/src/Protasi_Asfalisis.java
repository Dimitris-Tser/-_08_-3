import java.util.ArrayList;

class ProtasAsfalisis {
    private String asfalizomenos;
    private String diakimeno_asfalisis;
    private String asfalistra;
    private String periodos_asfalisis;
    private String katastasi;
    private static ArrayList<ProtasAsfalisis> asfalisisCatalog;

    public ProtasAsfalisis(String asfalizomenos, String diakimeno_asfalisis, String asfalistra, String periodos_asfalisis, String katastasi) {
        this.asfalizomenos = asfalizomenos;
        this.diakimeno_asfalisis = diakimeno_asfalisis;
        this.asfalistra = asfalistra;
        this.periodos_asfalisis = periodos_asfalisis;
        this.katastasi = katastasi;
    }

    // Getter and setter methods
    public String getAsfalizomenos() { return asfalizomenos; }
    public void setAsfalizomenos(String asfalizomenos) { this.asfalizomenos = asfalizomenos; }

    public String getDiakimenoAsfalisis() { return diakimeno_asfalisis; }
    public void setDiakimenoAsfalisis(String diakimeno_asfalisis) { this.diakimeno_asfalisis = diakimeno_asfalisis; }

    public String getAsfalistra() { return asfalistra; }
    public void setAsfalistra(String asfalistra) { this.asfalistra = asfalistra; }

    public String getPeriodosAsfalisis() { return periodos_asfalisis; }
    public void setPeriodosAsfalisis(String periodos_asfalisis) { this.periodos_asfalisis = periodos_asfalisis; }

    public String getKatastasi() { return katastasi; }
    public void setKatastasi(String katastasi) { this.katastasi = katastasi; }

    public void addToCatalog() {
        if (asfalisisCatalog == null) {
            asfalisisCatalog = new ArrayList<>();
        }
        asfalisisCatalog.add(this);
    }

    public void printData() {
        System.out.println("ProtasAsfalisis: " + asfalizomenos + ", " + diakimeno_asfalisis + ", " + asfalistra + ", " + periodos_asfalisis + ", " + katastasi);
    }
}