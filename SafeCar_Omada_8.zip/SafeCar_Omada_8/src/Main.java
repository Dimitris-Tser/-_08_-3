public class Main {
    public static void main(String[] args) {
        // Creating objects
    	Idioktitis idioktitis = new Idioktitis("John Doe", "123456789", "john@example.com");
        Pelatis pelatis = new Pelatis("John Doe", "123456789", "john@example.com", "GR123456789");
        Ohima ohima = new Ohima("Toyota", "Corolla", "Car", 12345, "Full");
        Profora profora = new Profora(20.0, "Yearly Discount");
        ProtasAsfalisis protasAsfalisis = new ProtasAsfalisis("John Doe", "Vehicle Insurance", "500", "1 Year", "Active");
        Radevou radevou = new Radevou("Meeting with Agent", "2024-06-10");
        Ekthesi ekthesi = new Ekthesi("2024-06-01", 12345, "Accident report");
        Pragmatognomonas pragmatognomonas = new Pragmatognomonas("Jane Smith", "Vehicle Expert", "987654321");
        Ikonomiki_Katastasi ikonomikiKatastasi = new Ikonomiki_Katastasi(100000.0, 50000.0, 50000.0);
        Paketo_Asfalisis paketo1 = new Paketo_Asfalisis("Basic Package");
        Paketo_Asfalisis paketo2 = new Paketo_Asfalisis("Premium Package");
        Praktoras praktoras = new Praktoras("John Doe", "Ασφαλιστής", "123456789");

        // Adding insurance packages to the catalog
        Paketo_Asfalisis.addToCatalog(paketo1);
        Paketo_Asfalisis.addToCatalog(paketo2);
        
        // Adding objects to catalogs
        ohima.addToCatalog();
        profora.addToCatalog();
        protasAsfalisis.addToCatalog();
        radevou.addToCatalog();
        ekthesi.addToCatalog();

        // Printing data
        idioktitis.printData();
        pelatis.printData();
        ohima.printData();
        profora.printData();
        protasAsfalisis.printData();
        radevou.printData();
        ekthesi.printData();
        pragmatognomonas.printData();
        ikonomikiKatastasi.printData();
        praktoras.printData();
        
        praktoras.apostoliEgrafonAsfalistiki("example@example.com", "Insurance documents");
        praktoras.enimerosiPelatiKatastasiAsfalistrou("Mary Smith", "Active");
        
     // Printing the catalog of insurance packages
        Paketo_Asfalisis.printCatalog();
    }
}
