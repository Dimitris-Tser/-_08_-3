class Ikonomiki_Katastasi {
    private double esoda;
    private double ejoda;
    private double budget;

    public Ikonomiki_Katastasi(double esoda, double ejoda, double budget) {
        this.esoda = esoda;
        this.ejoda = ejoda;
        this.budget = budget;
    }

    // Getter and setter methods
    public double getEsoda() {
        return esoda;
    }

    public void setEsoda(double esoda) {
        this.esoda = esoda;
    }

    public double getEjoda() {
        return ejoda;
    }

    public void setEjoda(double ejoda) {
        this.ejoda = ejoda;
    }

    public double getBudget() {
        return budget;
    }

    public void setBudget(double budget) {
        this.budget = budget;
    }

    public void printData() {
        System.out.println("Ikonomiki Katastasi: Esoda = " + esoda + ", Ejoda = " + ejoda + ", Budget = " + budget);
    }
}
