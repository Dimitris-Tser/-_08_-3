
public class Pragmatognomonas {
    private String onomatoponimo;
    private String eidikotita;
    private String tilefono;

    public Pragmatognomonas(String onomatoponimo, String eidikotita, String tilefono) {
        this.onomatoponimo = onomatoponimo;
        this.eidikotita = eidikotita;
        this.tilefono = tilefono;
    }

    // Getter and setter methods
    public String getOnomatoponimo() { return onomatoponimo; }
    public void setOnomatoponimo(String onomatoponimo) { this.onomatoponimo = onomatoponimo; }

    public String getEidikotita() { return eidikotita; }
    public void setEidikotita(String eidikotita) { this.eidikotita = eidikotita; }

    public String getTilefono() { return tilefono; }
    public void setTilefono(String tilefono) { this.tilefono = tilefono; }

    public void printData() {
        System.out.println("Pragmatognomonas: " + onomatoponimo + ", " + eidikotita + ", " + tilefono);
    }
}
