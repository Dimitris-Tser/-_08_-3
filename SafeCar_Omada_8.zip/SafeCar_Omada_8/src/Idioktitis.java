
public class Idioktitis {
    private String onomatoponimo;
    private String tilefono;
    private String email;

    public Idioktitis(String onomatoponimo, String tilefono, String email) {
        this.onomatoponimo = onomatoponimo;
        this.tilefono = tilefono;
        this.email = email;
    }

    // Getter and setter methods
    public String getOnomatoponimo() { return onomatoponimo; }
    public void setOnomatoponimo(String onomatoponimo) { this.onomatoponimo = onomatoponimo; }

    public String getTilefono() { return tilefono; }
    public void setTilefono(String tilefono) { this.tilefono = tilefono; }

    public String getEmail() { return email; }
    public void setEmail(String email) { this.email = email; }

    public void printData() {
        System.out.println("Idioktitis: " + onomatoponimo + ", " + tilefono + ", " + email);
    }
}