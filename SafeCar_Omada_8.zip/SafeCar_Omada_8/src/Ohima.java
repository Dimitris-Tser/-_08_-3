import java.util.ArrayList;

class Ohima {
    private String marka;
    private String modelo;
    private String kathos_ohimatos;
    private int arithmos_pinakidas;
    private String typos_asfalisis;
    private static ArrayList<Ohima> ohimaCatalog;

    public Ohima(String marka, String modelo, String kathos_ohimatos, int arithmos_pinakidas, String typos_asfalisis) {
        this.marka = marka;
        this.modelo = modelo;
        this.kathos_ohimatos = kathos_ohimatos;
        this.arithmos_pinakidas = arithmos_pinakidas;
        this.typos_asfalisis = typos_asfalisis;
    }

    // Getter and setter methods
    public String getMarka() { return marka; }
    public void setMarka(String marka) { this.marka = marka; }

    public String getModelo() { return modelo; }
    public void setModelo(String modelo) { this.modelo = modelo; }

    public String getKathosOhimatos() { return kathos_ohimatos; }
    public void setKathosOhimatos(String kathos_ohimatos) { this.kathos_ohimatos = kathos_ohimatos; }

    public int getArithmosPinakidas() { return arithmos_pinakidas; }
    public void setArithmosPinakidas(int arithmos_pinakidas) { this.arithmos_pinakidas = arithmos_pinakidas; }

    public String getTyposAsfalisis() { return typos_asfalisis; }
    public void setTyposAsfalisis(String typos_asfalisis) { this.typos_asfalisis = typos_asfalisis; }

    public void addToCatalog() {
        if (ohimaCatalog == null) {
            ohimaCatalog = new ArrayList<>();
        }
        ohimaCatalog.add(this);
    }

    public void printData() {
        System.out.println("Ohima: " + marka + ", " + modelo + ", " + kathos_ohimatos + ", " + arithmos_pinakidas + ", " + typos_asfalisis);
    }
}
